var peh_oe_ji = "密謀推翻政府的工具。".replace(/(.{8})/g, "$1\n");
