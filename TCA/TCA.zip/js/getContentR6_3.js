var inputTaiwanEmpire = document.getElementById("getContentR6_taiwanEmpire");

if(inputTaiwanEmpire) var taiwanEmpire = inputTaiwanEmpire.value.replace(/(.{9})/g, "$1\n");