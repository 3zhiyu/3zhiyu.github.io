var taiwanEmpire = "贊同，日本殖民母國必須傾聽臺灣人的聲音。".replace(/(.{9})/g, "$1\n");
