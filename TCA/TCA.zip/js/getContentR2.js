var inputR2 = document.getElementById("contentR2")

if(inputR2) var contentR2 = inputR2.value.replace(/(.{8})/g, "$1\n");