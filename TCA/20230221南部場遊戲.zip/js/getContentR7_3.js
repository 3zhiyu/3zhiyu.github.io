var input_tsai_poe_hoe = document.getElementById("getContentR7_3");

if(input_tsai_poe_hoe) var tsai_poe_hoe = input_tsai_poe_hoe.value.replace(/(.{8})/g, "$1\n");