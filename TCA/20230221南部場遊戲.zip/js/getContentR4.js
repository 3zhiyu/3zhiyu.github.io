var inputR4 = document.getElementById("contentR4");

if (inputR4)  var contentR4 = inputR4.value.replace(/(.{9})/g, "$1\n");