var input_peh_oe_ji = document.getElementById("getContentR5_peh_oe_ji");

if(input_peh_oe_ji) var peh_oe_ji = input_peh_oe_ji.value.replace(/(.{8})/g, "$1\n");