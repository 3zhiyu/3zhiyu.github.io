var inputR3 = document.getElementById("contentR3");

if(inputR3) var contentR3 = inputR3.value.replace(/(.{9})/g, "$1\n");